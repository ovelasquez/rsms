<?php

namespace Rsms\TrabajandoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RsmsTrabajandoBundle extends Bundle
{
}
